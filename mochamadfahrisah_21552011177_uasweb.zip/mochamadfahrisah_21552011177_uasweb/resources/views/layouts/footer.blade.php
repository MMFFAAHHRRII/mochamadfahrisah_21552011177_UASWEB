<footer class="sticky-footer bg-white">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © NET-TRACKER 2024 by <a href="https://albimdkr.github.io/portfolio/" target="_blank">Albi Mudakar <i class="fas fa-external-link-alt"></i></a></span>
      </div>
    </div>
  </footer>